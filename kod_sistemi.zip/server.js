const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs-extra");
const path = require("path");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

const gamesPath = path.join(__dirname, "data/games.json");
const codesPath = path.join(__dirname, "data/codes.json");

fs.ensureFileSync(gamesPath);
fs.ensureFileSync(codesPath);

if (!fs.existsSync(gamesPath)) fs.writeJsonSync(gamesPath, []);
if (!fs.existsSync(codesPath)) fs.writeJsonSync(codesPath, []);

app.post("/oyun-ekle", async (req, res) => {
  const { email, password } = req.body;
  const games = await fs.readJson(gamesPath);
  const newGame = { id: Date.now(), email, password };
  games.push(newGame);
  await fs.writeJson(gamesPath, games);
  res.redirect("/admin.html");
});

app.post("/kod-olustur", async (req, res) => {
  const { game } = req.body;
  const codes = await fs.readJson(codesPath);
  const code = Math.random().toString(36).substr(2, 5).toUpperCase();
  codes.push({ code, gameId: parseInt(game) });
  await fs.writeJson(codesPath, codes);
  res.send(`Kod oluşturuldu: ${code} <br><a href="/admin.html">Geri Dön</a>`);
});

app.post("/kodu-kullan", async (req, res) => {
  const { code } = req.body;
  const codes = await fs.readJson(codesPath);
  const games = await fs.readJson(gamesPath);
  const match = codes.find(c => c.code === code.toUpperCase());
  if (match) {
    const game = games.find(g => g.id === match.gameId);
    if (game) {
      res.send(`
        <h2>Oyun Bilgileri</h2>
        <p><b>E-posta:</b> ${game.email}</p>
        <p><b>Şifre:</b> ${game.password}</p>
        <a href="/">Ana Sayfaya Dön</a>
      `);
    } else {
      res.send("Bu koda ait oyun bulunamadı.");
    }
  } else {
    res.send("Kod geçersiz.");
  }
});

app.listen(3000, () => {
  console.log("Sunucu 3000 portunda çalışıyor");
});